*REST API certificate project*

